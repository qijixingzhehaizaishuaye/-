package filter;

import bean.User;
import service.impl.UserServiceImpl;
import utils.Log;
import utils.SUtil;

import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

public class UserSeeEssay implements Filter {

    public UserSeeEssay() {
    }

	public void destroy() {
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// place your code here
		//用户看帖数量+1
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse resp = (HttpServletResponse) response;
		//session和cookies均没有用户，跳转到登陆界面
		HttpSession session = req.getSession();
		User user = (User) session.getAttribute(SUtil.SESSION_NAME_USER);//获取用户
		UserServiceImpl userService = new UserServiceImpl();
		if(userService.addSeeEssayCount(user.getUserName())){
			Log.debug(this.getClass().getName(), "成功增加" + user.getUserName() + "看帖次数！");
		}else{
			Log.debug(this.getClass().getName(), "增加" + user.getUserName() + "看帖次数失败！");
		}
		// pass the request along the filter chain
		chain.doFilter(req, resp);
	}

	public void init(FilterConfig fConfig) throws ServletException {
	}

}
