package servlet;

import bean.Like;
import bean.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import service.WriteService;
import service.impl.LikeServiceImpl;
import service.LikeService;
import utils.Log;
import utils.SUtil;

import java.io.IOException;

@WebServlet("/LikeServlet")
public class LikeServlet extends HttpServlet {


    public LikeServlet() {
        super();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //判断当前用户是否收藏了目前的文章，首先获取文章id
        HttpSession session = request.getSession();
        String way = request.getParameter(SUtil.PARAMETER_WAY);
        int w;
        try{
            w = Integer.parseInt(way);
        }catch(Exception e){
            w = WriteService.WAY_WRITE_NEW_ESSAY;
            Log.debug(this.getClass().getName(), "转化way出错，way=" + way);
        }
        String pid1 = request.getParameter(SUtil.PARAMETER_ID);
        Integer pid = Integer.valueOf(pid1);
        //获取用户id，此处直接从session中获取
        User user = (User) session.getAttribute(SUtil.SESSION_NAME_USER);
        Integer uid;

        if(user != null){//用户登录，提取id
            uid = user.getId();
            Log.debug(this.getClass().getName(), "Uid="+uid+",Pid="+pid);
        }else {
            uid = -1;
        }
        LikeServiceImpl likeService = new LikeServiceImpl();
        if (w != 2){
            boolean boolean1 = likeService.isLike(pid,uid);
           if(boolean1){
            response.sendRedirect(SUtil.URL_PAGE_USER);
        }else {
            Like like = likeService.addLike(pid,uid);;
            Log.debug(this.getClass().getName(),"添加的文章id为"+like.getPid()+" 添加的用户id为"+like.getUid());
            response.sendRedirect(SUtil.URL_SERVLET_USER);}

        }else{likeService.deleteLike(pid,uid);
            Log.debug(this.getClass().getName(),"删除成功");
            response.sendRedirect(SUtil.URL_SERVLET_USER);}
    }
    }
