package service.impl;

import dao.impl.UserDaoImpl;

public class DeleteServiceImpl {
    public boolean deleteuser(int id){
        UserDaoImpl userDao = new UserDaoImpl();
        return userDao.deleteuser(id);
}
}
