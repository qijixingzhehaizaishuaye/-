package dao;

import bean.Essay;
import bean.Like;

import java.util.List;

public interface LikeDao {
    //此项主要用于解决收藏相关问题
    public boolean isLike(int pid,int uid);
    //判断是否收藏
    public Like addLike(int pid,int uid);
    public List<Essay> getLike(int uid);
    public void deleteLike(int pid,int uid);
}
