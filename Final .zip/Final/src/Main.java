public class Main {
    public static void main(String[] args) {
        int a = 121%100;
        int b = 121%10;
        System.out.println(b);
        System.out.println(a);
    }
}