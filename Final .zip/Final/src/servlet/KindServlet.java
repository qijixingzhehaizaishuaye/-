package servlet;

import bean.Page;
import jakarta.servlet.annotation.WebServlet;
import service.impl.KindServiceImpl;
import utils.Log;
import utils.SUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;


@WebServlet("/KindServlet")
public class KindServlet extends HttpServlet {

    public KindServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String kind = request.getParameter(SUtil.PARAMETER_KIND);
		String nowPage = request.getParameter(SUtil.PARAMETER_NOWPAGE);
		String order = request.getParameter(SUtil.PARAMETER_ORDER);
		Log.debug(this.getClass().getName(), "kind=" + kind + " nowPage="
												+ nowPage + " order=" + order);
		session.setAttribute(SUtil.SESSION_NAME_KIND, kind);
		session.setAttribute(SUtil.SESSION_NAME_ORDER, order);
		KindServiceImpl kindService = new KindServiceImpl();
		Page page = kindService.getEssayByKind(kind, nowPage, order);
		if(page != null){
			session.setAttribute(SUtil.SESSION_NAME_PAGE, page);
			Log.debug(this.getClass().getName(), "page不为空，将重定向到kind.jsp");
		}else{
			Log.debug(this.getClass().getName(), "page为空");
		}
		response.sendRedirect(SUtil.URL_PAGE_KIND);
	}

}
