package filter;

import utils.Log;
import utils.SUtil;

import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DeleteEditEssay implements Filter {
    public DeleteEditEssay() {
    }
	public void destroy() {
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// place your code here
		//这一条是删除想要编辑的Essay
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse resp = (HttpServletResponse) response;
		//session和cookies均没有用户，跳转到登陆界面
		String uri = req.getRequestURI();
		Log.debug(this.getClass().getName(), "");
		List<String> noFilterUrls = new ArrayList<String>(Arrays.asList(SUtil.noFilterUrl_deleteEditEssay));
		if(!noFilterUrls.contains(uri)){
			HttpSession session = req.getSession();
			if(session.getAttribute(SUtil.SESSION_NAME_WRITEESSAY) !=null){
				session.removeAttribute(SUtil.SESSION_NAME_WRITEESSAY);
				Log.debug(this.getClass().getName(), "非写作页面，存在writeEssay，删除session！");
			}else{
				Log.debug(this.getClass().getName(), "非写作页面，不存在writeEssay，不删除session！");
			}
			
			
		}
		// pass the request along the filter chain
		
		//当离开了编辑的页面时，就要删掉想要编辑的页面。。。还没写
		chain.doFilter(req, resp);
	}

	public void init(FilterConfig fConfig) throws ServletException {

	}

}
