package service;

import bean.Essay;
import bean.Like;

import java.util.List;

public interface LikeService {
    public boolean isLike(Integer Pid,Integer Uid);
    public Like addLike(Integer Pid,Integer Uid);
    public List<Essay> getLike(Integer Uid);
    public void deleteLike(Integer Pid,Integer Uid);
}
