package servlet;

import bean.User;
import jakarta.servlet.annotation.WebServlet;
import service.impl.RegisterServiceImpl;
import utils.Log;
import utils.SUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {

    public RegisterServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName = request.getParameter(SUtil.PARAMETER_USERNAME);
		String password = request.getParameter(SUtil.PARAMETER_PASSWORD);
		String kind = request.getParameter(SUtil.PARAMETER_KIND);
		//此项为用户类型，普通用户与管理员
		RegisterServiceImpl registerService = new RegisterServiceImpl();
		User user = registerService.addUser(userName, password, kind);
		if(user != null){
			Log.debug(this.getClass().getName(), "成功注册，userName=" + user.getUserName());
			//成功注册
			HttpSession session = request.getSession();
			session.setAttribute(SUtil.SESSION_NAME_USER, user);
			response.sendRedirect(SUtil.URL_SERVLET_USER);
			//用户界面
		}else{
			//没有成功注册
			Log.debug(this.getClass().getName(), "未能成功注册userName=" + userName + "userPassword=" + password);
			response.sendRedirect(SUtil.URL_PAGE_REGISTER);
			//退回到注册页面
		}
	}

}
