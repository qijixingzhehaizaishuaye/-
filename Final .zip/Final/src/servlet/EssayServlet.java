package servlet;

import bean.Essay;
import jakarta.servlet.annotation.WebServlet;
import service.impl.EssayServiceImpl;
import utils.Log;
import utils.SUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;


@WebServlet("/EssayServlet")
public class EssayServlet extends HttpServlet {

    public EssayServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter(SUtil.PARAMETER_ID);
		EssayServiceImpl essayService = new EssayServiceImpl();
		Essay essay = essayService.getEssayById(id);
		if(essay != null){
			Log.debug(this.getClass().getName(), "essayName=" + essay.getEssayName());
			HttpSession session = request.getSession();
			session.setAttribute(SUtil.SESSION_NAME_ESSAY, essay);
			response.sendRedirect(SUtil.URL_PAGE_ESSAY);
			//成功就转到文章页
		}else{
			Log.debug(this.getClass().getName(), "获取文章失败，id=" + id);
			response.sendRedirect(SUtil.URL_PAGE_MAIN);
			//跳转到首页
		}
	}

}
