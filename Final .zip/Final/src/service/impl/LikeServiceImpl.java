package service.impl;

import bean.Essay;
import bean.Like;
import dao.impl.EssayDaoImpl;
import service.LikeService;
import dao.impl.LikeDaoImpl;
import utils.Log;

import java.util.List;


public class LikeServiceImpl implements LikeService {
    public boolean isLike(Integer Pid,Integer Uid) {
        int uid = -1;
        int pid = 0;
        uid = Uid;
        pid = Pid;
        LikeDaoImpl likeDao = new LikeDaoImpl();
        if(uid == -1 || pid == 0){
            Log.debug(this.getClass().getName(), "文章ID或用户ID为空");
            return false;
        }Log.debug(this.getClass().getName(), "文章ID= " + pid + "用户ID=" + uid);
        return likeDao.isLike(pid,uid);
    }
    public Like addLike(Integer Pid,Integer Uid){
        int uid = Uid;
        int pid = Pid;
        LikeDaoImpl likeDao = new LikeDaoImpl();
        return likeDao.addLike(pid,uid);
    }

    @Override
    public List<Essay> getLike(Integer Uid) {
        int uid = 0;
        uid = Uid;
        if(uid == -1){return null;}
        LikeDaoImpl LikeDao = new LikeDaoImpl();
        return LikeDao.getLike(uid);
    }

    @Override
    public void deleteLike(Integer Pid, Integer Uid) {
        int uid = -1;
        int pid = 0;
        uid = Uid;
        pid = Pid;
        LikeDaoImpl likeDao = new LikeDaoImpl();
        if(uid == -1 || pid == 0){
            Log.debug(this.getClass().getName(), "文章ID或用户ID为空");
        }else
            Log.debug(this.getClass().getName(), "文章ID= " + pid + "用户ID=" + uid);
        likeDao.deleteLike(pid,uid);
    }
}
