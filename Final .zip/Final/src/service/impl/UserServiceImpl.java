package service.impl;

import bean.Essay;
import bean.User;
import dao.impl.EssayDaoImpl;
import dao.impl.UserDaoImpl;
import service.UserService;
import utils.Log;

import java.util.List;

public class UserServiceImpl implements UserService {

	@Override
	public List<Essay> getEssayByWriterName(String name) {
		if(name == null){return null;}
		EssayDaoImpl essayDao = new EssayDaoImpl();
		return essayDao.getEssayByWriterName(name);
	}
	
	@Override
	public boolean addSeeEssayCount(String name){
		if(name == null){return false;}
		UserDaoImpl userDao = new UserDaoImpl();
		return userDao.addSeeEssayCount(name);
	}

	@Override
	public List<User> getusers() {
		Log.debug(this.getClass().getName(), "Service层调用Dao");
		UserDaoImpl userDao = new UserDaoImpl();
		Log.debug(this.getClass().getName(), "List抽取成功");
		return userDao.getusers();
	}
}
