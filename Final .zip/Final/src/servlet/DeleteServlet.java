package servlet;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import service.WriteService;
import service.impl.DeleteServiceImpl;
import utils.Log;
import utils.SUtil;

import java.io.IOException;

@WebServlet("/DeleteServlet")
public class DeleteServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String way = request.getParameter(SUtil.PARAMETER_WAY);
        int w;
        try{
            w = Integer.parseInt(way);
    }catch(Exception e){
        Log.debug(this.getClass().getName(), "转化way出错，way=" + way);
    }
        String id1 = request.getParameter(SUtil.PARAMETER_ID);
        int id = Integer.valueOf(id1);
        DeleteServiceImpl deleteService = new DeleteServiceImpl();
        boolean boolean1 = deleteService.deleteuser(id);
        if (boolean1){System.out.println("删除成功");}
        response.sendRedirect(SUtil.URL_SERVLET_USER);}
}
