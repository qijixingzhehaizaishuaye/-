package service.impl;

import dao.impl.UserDaoImpl;
import service.PersonService;

public class PersonServiceImpl implements PersonService {
    @Override
    public void updateperson(String person,String name) {
        UserDaoImpl userDao = new UserDaoImpl();
        userDao.updateperson(person,name);
    }

}
