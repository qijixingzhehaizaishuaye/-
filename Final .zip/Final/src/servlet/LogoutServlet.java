package servlet;

import jakarta.servlet.annotation.WebServlet;
import utils.SUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/LogoutServlet")
public class LogoutServlet extends HttpServlet {

    public LogoutServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getSession().removeAttribute("user");
		Cookie cookie = new Cookie("autologin", "sha-diao@zhongyu");
		cookie.setMaxAge(0);//立即删除cookie
		cookie.setPath(request.getContextPath());
		response.addCookie(cookie);
		response.sendRedirect(SUtil.URL_PAGE_LOGIN);
		//当用户退出的时候，就换到登陆的界面
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

}
