package servlet;

import bean.Page;
import jakarta.servlet.annotation.WebServlet;
import service.impl.MainServiceImpl;
import utils.Log;
import utils.SUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;


@WebServlet("/MainServlet")
public class MainServlet extends HttpServlet {

    public MainServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String nowPage = request.getParameter("nowPage");
		Log.debug(this.getClass().getName(), "nowPage= " + nowPage);
		MainServiceImpl mainService = new MainServiceImpl();
		Page page = mainService.getEssayByEssaySeeCount(nowPage);
		HttpSession session = request.getSession();
		session.setAttribute(SUtil.SESSION_NAME_PAGE, page);
		if(page != null){
			Log.debug(this.getClass().getName(), "获取数据成功，即将跳转至main.jsp");
			Log.debug(this.getClass().getName(), page.getEssaies().get(0).getEssayName());
		}

		response.sendRedirect(SUtil.URL_PAGE_MAIN);
	}

}
