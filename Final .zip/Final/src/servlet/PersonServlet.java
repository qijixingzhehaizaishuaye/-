package servlet;

import bean.User;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import service.PersonService;
import service.impl.PersonServiceImpl;
import utils.Log;
import utils.SUtil;

import java.io.IOException;

@WebServlet("/PersonServlet")
public class PersonServlet extends HttpServlet {
    public PersonServlet() {
        super();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String person = request.getParameter("person");
        User user = (User) session.getAttribute(SUtil.SESSION_NAME_USER);
        String name = user.getUserName();
        Log.debug(this.getClass().getName(), "用户："+name+"把个人信息改为"+person);
        PersonServiceImpl personService = new PersonServiceImpl();
        personService.updateperson(person,name);
        session.removeAttribute(SUtil.SESSION_NAME_USER);
        user.setPerson(person);
        session.setAttribute(SUtil.SESSION_NAME_USER, user);
        response.sendRedirect(SUtil.URL_PAGE_USER);
    }
}
