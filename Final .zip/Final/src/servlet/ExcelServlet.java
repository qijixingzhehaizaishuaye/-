package servlet;

import bean.Essay;
import bean.User;
import com.alibaba.excel.EasyExcel;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import utils.SUtil;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import static org.apache.commons.pool2.impl.CallStackTest.data;

@WebServlet("/ExcelServlet")
public class ExcelServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        Essay essay = (Essay) session.getAttribute(SUtil.SESSION_NAME_ESSAY);
        List<Essay> essays = new ArrayList<>();
        essays.add(essay);
//        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
//        response.setCharacterEncoding("utf-8");

        response.setContentType("application/x-download");
        response.setCharacterEncoding("UTF-8");
//        response.setHeader("Content-disposition", "attachment;filename=articles.xlsx");

        // 这里URLEncoder.encode可以防止中文乱码 当然和easyexcel没有关系
        String fileName = "essay.xlsx";
        response.setHeader("Content-disposition", "attachment;filename*=utf-8''" + fileName);
        EasyExcel.write(response.getOutputStream(), Essay.class).sheet("文章信息").doWrite(essays);

    }
}
