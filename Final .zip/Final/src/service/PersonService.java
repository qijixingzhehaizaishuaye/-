package service;

public interface PersonService {
    public void updateperson(String person,String name);
}
