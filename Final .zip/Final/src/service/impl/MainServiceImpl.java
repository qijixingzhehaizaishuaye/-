package service.impl;

import bean.Page;
import dao.impl.EssayDaoImpl;
import service.MainService;
import utils.Log;

public class MainServiceImpl implements MainService {

	@Override
	public Page getEssayByEssaySeeCount(String np) {
		int nowPage;
		try{
			nowPage = Integer.parseInt(np);
		}catch(Exception e){
			Log.error(this.getClass().getName(), "nowPage= " + np);
			nowPage = 1;
		}
		Log.debug(this.getClass().getName(), "主页面请求，nowPage=" + nowPage);
		EssayDaoImpl essayDao = new EssayDaoImpl();
		return essayDao.getEssayByEssaySeeCount(nowPage);
	}

}
