package dao.impl;

import bean.Essay;
import bean.Like;
import dao.LikeDao;
import utils.Log;
import utils.linkdb;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class LikeDaoImpl implements LikeDao {

    @Override
    public boolean isLike(int pid, int uid) {
        Connection coon = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            coon = linkdb.getConnection();
            stmt = coon.createStatement();
            String sql="SELECT * FROM likes WHERE uid = "+uid+" and pid = "+pid;
            rs = stmt.executeQuery(sql);
            if(rs.next()){
                Log.debug(this.getClass().getName(),"已经收藏");
                return true;
                //已经收藏
            }
        } catch (Exception e) {
             e.printStackTrace();
        }finally {
            linkdb.releaseConnection(coon);
        }
        Log.debug(this.getClass().getName(),"尚未收藏");
        return false;
    }

    @Override
    public Like addLike(int pid, int uid) {
        Connection coon = null;
        Statement stmt = null;
        ResultSet rs = null;
        Integer Pid = pid;
        Integer Uid = uid;
        Like like = new Like(Pid,Uid);
        try {
            coon = linkdb.getConnection();
            stmt = coon.createStatement();
            String sql= "INSERT INTO likes(likes.pid,likes.uid)"+"VALUES(" +pid +","+uid+")";
            int num = stmt.executeUpdate(sql);
            if(num > 0){
                Log.debug(this.getClass().getName(), "插入成功");
                return like;
            }
            Log.debug(this.getClass().getName(), "没有插入成功");
            return null;
        }catch (Exception e){
            e.printStackTrace();
        }finally{
            linkdb.releaseConnection(coon);
        }
        return null;
    }

    @Override
    public List<Essay> getLike(int uid) {

        //
        System.out.println("likedao执行");

        Connection coon = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            coon = linkdb.getConnection();
            stmt = coon.createStatement();
            String sql="SELECT * From essay,likes where likes.uid = "+uid+" AND likes.pid = essay.id";
            rs = stmt.executeQuery(sql);
            List<Essay> like_list = new ArrayList();
            while(rs.next()){
                //如果存在用户名
                System.out.println("查询无误");
                Essay essay = new Essay(rs.getInt("id"),rs.getString("essayName"),rs.getString("writerName")
                        ,rs.getString("essayContent"),rs.getString("issueDate"),rs.getString("lastChange")
                        ,rs.getString("otherInfo"),rs.getInt("essayKind"),rs.getInt("seeCount"));
                like_list.add(essay);
            }
            return like_list;
        }catch (Exception e) {
            e.printStackTrace();
        }finally{
            linkdb.releaseConnection(coon);
        }
        return null;
    }

    @Override
    public void deleteLike(int pid, int uid) {
        Connection coon = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            coon = linkdb.getConnection();
            stmt = coon.createStatement();
            String sql="DELETE FROM likes WHERE uid = "+uid+" and pid = "+pid;
            int num = stmt.executeUpdate(sql);
            if(num>0){
                Log.debug(this.getClass().getName(),"删除成功");
                //已经收藏
            }else { Log.debug(this.getClass().getName(),"删除失败");}
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            linkdb.releaseConnection(coon);
        }


    }
}
