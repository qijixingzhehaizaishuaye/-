package servlet;

import bean.Essay;
import bean.Like;
import bean.User;
import jakarta.servlet.annotation.WebServlet;
import service.EssayService;
import service.UserService;
import service.impl.EssayServiceImpl;
import service.impl.LikeServiceImpl;
import service.impl.LoginServiceImpl;
import service.impl.UserServiceImpl;
import utils.Log;
import utils.SUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {


    public UserServlet() {
        super();

    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute(SUtil.SESSION_NAME_USER);


		if(user != null){
			LoginServiceImpl loginService = new LoginServiceImpl();

			user = loginService.loginUser(user.getUserName(), user.getUserPassword());
			session.setAttribute(SUtil.SESSION_NAME_USER, user);

			Log.debug(this.getClass().getName(), "获取name=" + user.getUserName() + "所写文章信息");
			UserServiceImpl userService = new UserServiceImpl();
			List<Essay> essayList = userService.getEssayByWriterName(user.getUserName());
			session.setAttribute(SUtil.SESSION_NAME_ESSAYLIST, essayList);

			Log.debug(this.getClass().getName(), "获取name=" + user.getUserName() + "所收藏的文章信息");
			LikeServiceImpl likeService = new LikeServiceImpl();
			List<Essay> LikeList = likeService.getLike(user.getId());
			session.setAttribute(SUtil.SESSION_NAME_LikeLIST, LikeList);

			EssayServiceImpl essayService = new EssayServiceImpl();
			int count = essayService.getEssaynum();
			String num = String.valueOf(count);
			session.setAttribute(SUtil.SESSION_ESSAYNUM,num);
			Log.debug(this.getClass().getName(), "文章总数目为"+num);

			Log.debug(this.getClass().getName(), "全部人员信息，仅管理员可见");
			UserServiceImpl userService1 = new UserServiceImpl();
			List<User> userslist = userService1.getusers();
			session.setAttribute(SUtil.SESSION_NAME_USERLIST, userslist);

			Log.debug(this.getClass().getName(), "获取完将跳转至" + SUtil.URL_PAGE_USER);
			response.sendRedirect(SUtil.URL_PAGE_USER);
		}
	}

}
