package service;

import bean.Page;

public interface MainService {
	public Page getEssayByEssaySeeCount(String nowPage);
	//首页展示最热的文章
}
