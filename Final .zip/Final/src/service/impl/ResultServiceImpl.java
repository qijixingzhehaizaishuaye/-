package service.impl;


import bean.Page;
import dao.impl.EssayDaoImpl;
import service.ResultService;
import utils.Log;

public class ResultServiceImpl implements ResultService {

	@Override
	public Page getEssayByName(String name, String np, String od) {
		if(name == null) return null;
		int nowPage;
		try{
			nowPage = Integer.parseInt(np);
		}catch(Exception e){
			Log.error(this.getClass().getName(), "nowPage" + np);
			nowPage = 1;
		}
		
		int order;
		try{
			order = Integer.parseInt(od);
		}catch(Exception e){
			Log.error(this.getClass().getName(), "order=" + od);
			order = Page.ORDER_HOT;
		}
		EssayDaoImpl essayDao = new EssayDaoImpl();
		Log.debug(this.getClass().getName(), "name=" + name + " nowPage=" + nowPage + " order=" + order);
		return essayDao.getEssayByEssayName(name, nowPage, order);
	}

}
