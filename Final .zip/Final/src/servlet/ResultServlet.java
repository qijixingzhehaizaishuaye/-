package servlet;

import bean.Page;
import jakarta.servlet.annotation.WebServlet;
import service.impl.ResultServiceImpl;
import utils.Log;
import utils.SUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;


@WebServlet("/ResultServlet")
public class ResultServlet extends HttpServlet {

    public ResultServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String essayName = request.getParameter(SUtil.PARAMETER_ESSAYNAME);
		String nowPage = request.getParameter(SUtil.PARAMETER_NOWPAGE);
		String order = request.getParameter(SUtil.PARAMETER_ORDER);
		Log.debug(this.getClass().getName(), "name=" + essayName + "nowPage=" + nowPage +
				nowPage + " order=" + order);
		ResultServiceImpl resultService = new ResultServiceImpl();
		Page page = resultService.getEssayByName(essayName, nowPage, order);
		HttpSession session = request.getSession();
		session.setAttribute(SUtil.SESSION_NAME_ESSAYNAME, essayName);
		//这个是暂时性设置搜索名称的，正确的做法应该是传到page里面
		session.setAttribute(SUtil.SESSION_NAME_PAGE, page);
		if(page != null){
			session.setAttribute(SUtil.SESSION_NAME_ESSAY, essayName);
			Log.debug(this.getClass().getName(), "请求结果page对象不为空,重定向到result.jsp");
		}
		
		response.sendRedirect(SUtil.URL_PAGE_RESULT);
	}

}
