package servlet;

import bean.Essay;
import bean.User;
import jakarta.servlet.annotation.WebServlet;
import service.WriteService;
import service.impl.WriteServiceImpl;
import utils.Log;
import utils.SUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/WriteServlet")
public class WriteServlet extends HttpServlet {

    public WriteServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		session.removeAttribute(SUtil.SESSION_NAME_WRITEESSAY);
		User user = (User) session.getAttribute(SUtil.SESSION_NAME_USER);

		String way = request.getParameter(SUtil.PARAMETER_WAY);
		String id  = request.getParameter(SUtil.PARAMETER_ID);
		String essayName = request.getParameter(SUtil.PARAMETER_ESSAYNAME);
		String essayContent = request.getParameter(SUtil.PARAMETER_ESSAYCONTENT);
		String otherInfo = request.getParameter(SUtil.PARAMETER_OTHERINFO);
		String essayKind = request.getParameter(SUtil.PARAMETER_ESSAYKIND);

		WriteServiceImpl writeService = new WriteServiceImpl();
		Essay essay = writeService.writeEssay(way, id, essayName, user.getUserName(),
				essayContent, otherInfo, essayKind);
		
		int w;
		try{
			w = Integer.parseInt(way);
		}catch(Exception e){
			w = WriteService.WAY_WRITE_NEW_ESSAY;
			Log.debug(this.getClass().getName(), "转化way出错，way=" + way);
		}
		//暂时先靠这个来确定是
		if(w == WriteService.WAY_GET_ESSAY_ID){
			//获得一篇文章去修改...
			session.setAttribute(SUtil.SESSION_NAME_WRITEESSAY, essay);
			//这是要写的文章
			response.sendRedirect(SUtil.URL_PAGE_WRITE);
			
		}else if(w == WriteService.WAY_UPDATE_ESSAY){
			//更新一篇文章
			session.setAttribute(SUtil.SESSION_NAME_ESSAY, essay);

			response.sendRedirect(SUtil.URL_PAGE_ESSAY);

		}else if(w == WriteService.WAY_WRITE_NEW_ESSAY){
			//新增加了一篇文章
			session.setAttribute(SUtil.SESSION_NAME_ESSAY, essay);

			response.sendRedirect(SUtil.URL_PAGE_ESSAY);
		}else if(w == WriteService.WAY_DELETE_ESSAY){

			response.sendRedirect(SUtil.URL_SERVLET_USER);
		}
	}
}
