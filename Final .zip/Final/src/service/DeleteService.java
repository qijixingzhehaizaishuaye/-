package service;

import dao.impl.UserDaoImpl;

public interface DeleteService {
    public boolean deleteuser(int id);
}
